# AdvanceFileCompressor
This is a simple example for compressing image files.
